<?php
$array=array();
$prod1=new stdClass();
$prod2=new stdClass();

$prod1->codigoBarra=123;
$prod1->nombre="Chocolate";
$prod1->precio=20.50;

$prod2->codigoBarra=345;
$prod2->nombre="Alfajor";
$prod2->precio=10.50;

array_push($array,$prod1);
array_push($array,$prod2);

var_dump($array);


?>