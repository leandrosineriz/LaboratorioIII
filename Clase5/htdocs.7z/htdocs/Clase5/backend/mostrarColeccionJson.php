<?php

$productos=$_POST["productos"];

//var_dump($productos);

$objProductos=json_decode($productos);

$retorno='';

foreach($objProductos as $value)
{
    $retorno.= $value->codigoBarra."-".$value->nombre."-".$value->precio."\n";
}

echo $retorno;

?>