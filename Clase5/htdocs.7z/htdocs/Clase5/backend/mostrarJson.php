<?php

$producto=$_POST["producto"];

//var_dump($_POST["producto"]);

$jsonObj=json_decode($producto);

$jsonEnviar=json_encode($jsonObj);

echo $jsonEnviar;


?>