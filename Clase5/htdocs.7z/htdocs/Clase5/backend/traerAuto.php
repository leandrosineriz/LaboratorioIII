<?php

$path="../archivos/auto.json";
$arch=fopen($path,"r");

$lectora='';

while(!feof($arch))
{
    $lectora.=fgets($arch);
}

fclose($arch);

$enviar=json_encode($lectora);

echo $lectora;


?>