/// <reference path="../ajax/ajax.ts" />

namespace Test {

    export function EjercicioTres() {
        var jsonObj: any = { "codigoBarra": 123, "nombre": "Choclate", "precio": 20.50 };
        var pagina = "backend/mostrarJson.php";

        let ajax: Ajax = new Ajax();
        let params: string = "producto=" + JSON.stringify(jsonObj);

        ajax.Post(pagina,
            (resultado: string) => {

                var objJsonRecibido: any = JSON.parse(resultado);

                console.log(objJsonRecibido.codigoBarra + "-" + objJsonRecibido.nombre + "-" + objJsonRecibido.precio);
                (<HTMLDivElement>document.getElementById("mostrar")).innerText=resultado;
            }, params, Fail);

    }

    export function EjercicioCuatro() {

        var productos: any = [
            { "codigoBarra": 123, "nombre": "Choclate", "precio": 20.50 },
            { "codigoBarra": 456, "nombre": "Alfajor", "precio": 10.80 },
            { "codigoBarra": 789, "nombre": "Caramelo", "precio": 2 }
        ];
        var pagina = "backend/mostrarColeccionJson.php";

        let ajax: Ajax = new Ajax();
        let params: string = "productos=" + JSON.stringify(productos);

        ajax.Post(pagina,
            (resultado: string) => {
                console.log(resultado);
                (<HTMLDivElement>document.getElementById("mostrar")).innerText=resultado;
            }, params, Fail);

    }

    export function EjercicioCinco()
    {
        var pagina = "backend/recibirJson.php";

        let ajax: Ajax = new Ajax();
        

        ajax.Post(pagina,
            (resultado: string) => {
                console.log(resultado);
                (<HTMLDivElement>document.getElementById("mostrar")).innerText=resultado;
            },'', Fail);
    }

    export function EjercicioSiete()
    {
        var pagina = "backend/traerAuto.php";

        let ajax: Ajax = new Ajax();
        

        ajax.Post(pagina,
            (resultado: string) => {
                console.log(resultado);
                (<HTMLDivElement>document.getElementById("mostrar")).innerText=resultado;
            },'', Fail);

    }

    export function EjercicioOcho()
    {
        var pagina = "backend/traerAuto.php";

        let ajax: Ajax = new Ajax();
        

        ajax.Post(pagina,
            (resultado: string) => {
                console.log(resultado);
                let objAuto:any=JSON.parse(resultado);
                (<HTMLDivElement>document.getElementById("mostrar")).innerHTML="<table><tr><td>ID</td><td><input type='text' style='display:block' value='"+objAuto.Id+"'</td></tr></table>";
            },'', Fail);

    }

    
    function Fail(retorno: string): void {
        console.clear();
        console.log("ERROR!!!");
        console.log(retorno);
    }
}