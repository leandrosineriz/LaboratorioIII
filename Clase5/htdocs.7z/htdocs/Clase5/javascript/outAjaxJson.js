var Ajax = /** @class */ (function () {
    function Ajax() {
        var _this = this;
        this.Get = function (ruta, success, params, error) {
            if (params === void 0) { params = ""; }
            var parametros = params.length > 0 ? params : "";
            ruta = params.length > 0 ? ruta + "?" + parametros : ruta;
            _this._xhr.open('GET', ruta);
            _this._xhr.send();
            _this._xhr.onreadystatechange = function () {
                if (_this._xhr.readyState === Ajax.DONE) {
                    if (_this._xhr.status === Ajax.OK) {
                        success(_this._xhr.responseText);
                    }
                    else {
                        if (error !== undefined) {
                            error(_this._xhr.status);
                        }
                    }
                }
            };
        };
        this.Post = function (ruta, success, params, error) {
            if (params === void 0) { params = ""; }
            var parametros = params.length > 0 ? params : "";
            _this._xhr.open('POST', ruta, true);
            _this._xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            _this._xhr.send(parametros);
            _this._xhr.onreadystatechange = function () {
                if (_this._xhr.readyState === Ajax.DONE) {
                    if (_this._xhr.status === Ajax.OK) {
                        success(_this._xhr.responseText);
                    }
                    else {
                        if (error !== undefined) {
                            error(_this._xhr.status);
                        }
                    }
                }
            };
        };
        this._xhr = new XMLHttpRequest();
        Ajax.DONE = 4;
        Ajax.OK = 200;
    }
    return Ajax;
}());
/// <reference path="../ajax/ajax.ts" />
var Test;
(function (Test) {
    function EjercicioTres() {
        var jsonObj = { "codigoBarra": 123, "nombre": "Choclate", "precio": 20.50 };
        var pagina = "backend/mostrarJson.php";
        var ajax = new Ajax();
        var params = "producto=" + JSON.stringify(jsonObj);
        ajax.Post(pagina, function (resultado) {
            var objJsonRecibido = JSON.parse(resultado);
            console.log(objJsonRecibido.codigoBarra + "-" + objJsonRecibido.nombre + "-" + objJsonRecibido.precio);
            document.getElementById("mostrar").innerText = resultado;
        }, params, Fail);
    }
    Test.EjercicioTres = EjercicioTres;
    function EjercicioCuatro() {
        var productos = [
            { "codigoBarra": 123, "nombre": "Choclate", "precio": 20.50 },
            { "codigoBarra": 456, "nombre": "Alfajor", "precio": 10.80 },
            { "codigoBarra": 789, "nombre": "Caramelo", "precio": 2 }
        ];
        var pagina = "backend/mostrarColeccionJson.php";
        var ajax = new Ajax();
        var params = "productos=" + JSON.stringify(productos);
        ajax.Post(pagina, function (resultado) {
            console.log(resultado);
            document.getElementById("mostrar").innerText = resultado;
        }, params, Fail);
    }
    Test.EjercicioCuatro = EjercicioCuatro;
    function EjercicioCinco() {
        var pagina = "backend/recibirJson.php";
        var ajax = new Ajax();
        ajax.Post(pagina, function (resultado) {
            console.log(resultado);
            document.getElementById("mostrar").innerText = resultado;
        }, '', Fail);
    }
    Test.EjercicioCinco = EjercicioCinco;
    function EjercicioSiete() {
        var pagina = "backend/traerAuto.php";
        var ajax = new Ajax();
        ajax.Post(pagina, function (resultado) {
            console.log(resultado);
            document.getElementById("mostrar").innerText = resultado;
        }, '', Fail);
    }
    Test.EjercicioSiete = EjercicioSiete;
    function EjercicioOcho() {
        var pagina = "backend/traerAuto.php";
        var ajax = new Ajax();
        ajax.Post(pagina, function (resultado) {
            console.log(resultado);
            var objAuto = JSON.parse(resultado);
            document.getElementById("mostrar").innerHTML = "<table><tr><td>ID</td><td><input type='text' style='display:block;' value='" + objAuto.Id + "'</td></tr></table>";
        }, '', Fail);
    }
    Test.EjercicioOcho = EjercicioOcho;
    function Fail(retorno) {
        console.clear();
        console.log("ERROR!!!");
        console.log(retorno);
    }
})(Test || (Test = {}));
