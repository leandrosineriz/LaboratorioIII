"use strict";
/// <reference path="../ajax/ajax.ts" />
var Test;
(function (Test) {
    function EjercicioTres() {
        var jsonObj = { "codigoBarra": 123, "nombre": "Choclate", "precio": 20.50 };
        var pagina = "backend/mostrarJson.php";
        var ajax = new Ajax();
        var params = "producto=" + JSON.stringify(jsonObj);
        ajax.Post(pagina, function (resultado) {
            //console.log(resultado);
        }, params, Fail);
    }
    Test.EjercicioTres = EjercicioTres;
    function Fail(retorno) {
        console.clear();
        console.log("ERROR!!!");
        console.log(retorno);
    }
})(Test || (Test = {}));
